export {setupAntd} from '/@/plugins/antd'
export {setupDirectives} from '/@/plugins/directives'
export {setupCustomComponents} from '/@/plugins/customComponents'
export {setupGlobalMethods} from '/@/plugins/globalMethods'
