interface Window {
    baseUrl: string;
}
