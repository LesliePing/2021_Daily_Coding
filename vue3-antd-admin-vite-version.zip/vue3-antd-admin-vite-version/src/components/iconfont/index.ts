import IconFont from './icon-font'
export {IconFont}
