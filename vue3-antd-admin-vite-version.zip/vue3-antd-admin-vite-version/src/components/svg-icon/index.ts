import SvgIcon from './svg-icon.vue'

export {
    SvgIcon
}
