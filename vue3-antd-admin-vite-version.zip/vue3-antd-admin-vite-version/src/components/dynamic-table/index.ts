import DynamicTable from './dynamic-table.vue'
export {DynamicTable}
