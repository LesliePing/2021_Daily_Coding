declare module 'mitt' {
    import mitt from 'mitt'
    export default mitt
}

declare module 'blueimp-md5' {
    import md5 from 'blueimp-md5'
    export default md5
}
