// 动态设置资源路径（目的是给后端人员做服务端渲染，例如JSP动态资源路由）
// __webpack_public_path__ = process.env.NODE_ENV == 'development' ? '' : window.baseUrl
