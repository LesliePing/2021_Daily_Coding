// 提供了 confirm alert 两个装饰器
export * from './confirm'

// 函数防抖
export { default as debounce } from './debounce'

// 函数节流
export { default as throttle } from './throttle'
